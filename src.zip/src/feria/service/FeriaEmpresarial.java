package feria.service;

import java.util.ArrayList;
import java.util.List;

import feria.model.Comentario;
import feria.model.Empresa;
import feria.model.Stand;
import feria.model.Visitante;

public class FeriaEmpresarial {

    private List<Empresa> empresas = new ArrayList<>();
    private List<Stand> stands = new ArrayList<>();
    private List<Visitante> visitantes = new ArrayList<>();
    private List<Comentario> comentarios = new ArrayList<>();

    public void registrarEmpresa(Empresa e) {
        empresas.add(e);
    }

    public void registrarVisitante(Visitante v) {
        visitantes.add(v);
    }

    public void asignarStand(Empresa e, Stand s) {
        stands.add(s);
    }

    public void agregarComentario(Comentario c) {
        comentarios.add(c);
    }

    public void generarReporte() {
        System.out.println("===== REPORTE FERIA EMPRESARIAL =====");
        System.out.println("Empresas registradas: " + empresas.size());
        System.out.println("Stands registrados: " + stands.size());
        System.out.println("Visitantes registrados: " + visitantes.size());
        System.out.println("Comentarios registrados: " + comentarios.size());
        System.out.println("===================================");
    }
}
