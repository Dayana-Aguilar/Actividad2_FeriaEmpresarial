package feria.model;

public class Comentario {

    private String nombreVisitante;
    private String fecha;
    private int calificacion; // 1 a 5
    private String comentario;

    public Comentario(String nombreVisitante, String fecha, int calificacion, String comentario) {
        this.nombreVisitante = nombreVisitante;
        this.fecha = fecha;
        this.calificacion = calificacion;
        this.comentario = comentario;
    }

    public String getNombreVisitante() {
        return nombreVisitante;
    }

    public String getFecha() {
        return fecha;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public String getComentario() {
        return comentario;
    }
}


