package feria.model;

public class Stand {

    private int numero;
    private String ubicacion;
    private String tamano;

    public Stand(int numero, String ubicacion, String tamano) {
        this.numero = numero;
        this.ubicacion = ubicacion;
        this.tamano = tamano;
    }

    public int getNumero() {
        return numero;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public String getTamano() {
        return tamano;
    }
}
